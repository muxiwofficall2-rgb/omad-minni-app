import { type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import {
  ArrowLeft, ArrowRight, BadgeCheck, BarChart3, CalendarDays, Check,
  ChevronRight, CircleHelp, ClipboardList, Clock3, FileCheck2, FileText,
  Headphones, LockKeyhole, MapPin, Menu, MessageCircle, Moon, Paperclip, Phone,
  Plane, Plus, Send, ShieldCheck, Sun, Ticket, Upload, UserRound, UsersRound,
  X, ExternalLink, Minus, Map, Building2
} from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import logoPath from '@assets/omad-tour-logo.jpg';

const queryClient = new QueryClient();

type Language = 'uz' | 'ru' | 'tk' | 'en';
type RequestItem = { id: string; type: string; title: string; status: 'New' | 'In review' | 'Completed'; detail: string; created: string };

const DESTINATIONS = {
  telegram: 'https://t.me/OMAD_TOUR9094',
  whatsapp: 'https://wa.me/79811939094',
  max: 'https://max.ru/u/f9LHodD0cOLdbuGpTx71gF1lKZN5kU8yUUSak1S5b7PAPNv3_lID0dB_rW0',
  sms: 'sms:+79811939094',
  phone: 'tel:+79811939094',
  specialistTelegram: 'https://t.me/AVIAKASSA9094',
  specialistWhatsapp: 'https://wa.me/79379499094',
  specialistImo: 'https://imo.im/',
  specialistPhone: 'tel:+79379499094',
  maps: 'https://yandex.ru/maps/org/omad_tour/106008133546?si=8720czm5kktd7kxt80d3gv6mew',
  visa: 'https://visa.mfa.uz/ruxsat/view',
};
const labels: Record<Language, Record<string, string>> = {
  uz: { home: 'Bosh sahifa', tickets: 'Aviachiptalar', visa: 'Viza xizmatlari', requests: 'Murojaatlar', help: 'Yordam', specialist: 'Mutaxassis', groups: 'Foydali guruhlar', address: 'Ofis manzili', next: 'Davom etish', back: 'Orqaga', send: 'Yuborish', language: 'Til', local: 'Ma’lumotlar faqat ushbu qurilmada saqlanadi' },
  ru: { home: 'Главная', tickets: 'Авиабилеты', visa: 'Визовые услуги', requests: 'Мои заявки', help: 'Помощь', specialist: 'Специалист', groups: 'Полезные группы', address: 'Адрес офиса', next: 'Продолжить', back: 'Назад', send: 'Отправить', language: 'Язык', local: 'Данные хранятся только на этом устройстве' },
  tk: { home: 'Baş sahypa', tickets: 'Uçar petekleri', visa: 'Wiza hyzmatlary', requests: 'Arzalar', help: 'Kömek', specialist: 'Hünärmen', groups: 'Peýdaly toparlar', address: 'Ofisiň salgysy', next: 'Dowam et', back: 'Yza', send: 'Ugrat', language: 'Dil', local: 'Maglumatlar diňe şu enjamda saklanýar' },
  en: { home: 'Home', tickets: 'Air tickets', visa: 'Visa services', requests: 'My requests', help: 'Help', specialist: 'Specialist', groups: 'Useful groups', address: 'Office address', next: 'Continue', back: 'Back', send: 'Send', language: 'Language', local: 'Your data stays on this device' },
};
const tr = (language: Language, key: string) => labels[language][key] ?? labels.en[key] ?? key;

function useLocalStorage<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try { const saved = localStorage.getItem(key); return saved ? JSON.parse(saved) as T : initial; } catch { return initial; }
  });
  useEffect(() => { localStorage.setItem(key, JSON.stringify(value)); }, [key, value]);
  return [value, setValue] as const;
}

function Logo({ size = 'md', onTap }: { size?: 'sm' | 'md' | 'lg'; onTap?: () => void }) {
  return <button type="button" onClick={onTap} className={`brand-mark brand-${size}`} data-testid="button-brand-logo" aria-label="Omad Tour logo"><img src={logoPath} alt="Omad Tour" /></button>;
}

function Shell({ children, language, setLanguage, dark, setDark, taps, setTaps }: { children: ReactNode; language: Language; setLanguage: (v: Language) => void; dark: boolean; setDark: (v: boolean) => void; taps: number; setTaps: (v: number) => void }) {
  const [location, setLocation] = useLocation();
  const isHome = location === '/';
  const [menuOpen, setMenuOpen] = useState(false);
  const nav = [
    { href: '/', key: 'home', icon: Plane },
    { href: '/tickets', key: 'tickets', icon: Ticket },
    { href: '/visa', key: 'visa', icon: FileCheck2 },
    { href: '/requests', key: 'requests', icon: ClipboardList },
  ];
  return <div className="grain min-h-[100dvh] shell-bg">
    <header className="sticky top-0 z-10 border-b bg-background/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-3xl items-center justify-between px-4">
        <div className="flex items-center gap-3">
          {!isHome && <button type="button" onClick={() => setLocation(location.startsWith('/visa/') ? '/visa' : '/')} className="icon-button" data-testid="button-header-home" aria-label="Orqaga"><ArrowLeft size={19} /></button>}
          <Logo size="sm" onTap={() => { const next = taps + 1; setTaps(next); if (next >= 5) { setTaps(0); setLocation('/admin'); } }} />
          <div><p className="font-display text-sm font-bold leading-none">Omad Tour</p><p className="mt-1 text-[10px] font-semibold uppercase tracking-[.18em] text-muted-foreground">travel desk · SPB</p></div>
        </div>
        <div className="flex items-center gap-1.5">
          <button type="button" className="icon-button" onClick={() => setDark(!dark)} data-testid="button-toggle-theme" aria-label="Toggle theme">{dark ? <Sun size={18} /> : <Moon size={18} />}</button>
          <button type="button" className="icon-button md:hidden" onClick={() => setMenuOpen(!menuOpen)} data-testid="button-open-menu"><Menu size={19} /></button>
          <select value={language} onChange={(e) => setLanguage(e.target.value as Language)} className="language-select hidden md:block" aria-label={tr(language, 'language')} data-testid="select-language">
            <option value="uz">UZ</option><option value="ru">RU</option><option value="tk">TK</option><option value="en">EN</option>
          </select>
        </div>
      </div>
      {menuOpen && <div className="border-t bg-card px-4 py-3 md:hidden">
        <div className="grid grid-cols-2 gap-2">{nav.map(({ href, key, icon: Icon }) => <Link key={href} href={href} onClick={() => setMenuOpen(false)} className="menu-link" data-testid={`link-menu-${key}`}><Icon size={16} />{tr(language, key)}</Link>)}</div>
        <select value={language} onChange={(e) => setLanguage(e.target.value as Language)} className="language-select mt-3 w-full" data-testid="select-language-mobile"><option value="uz">O‘zbekcha</option><option value="ru">Русский</option><option value="tk">Türkmençe</option><option value="en">English</option></select>
      </div>}
    </header>
    <main className={`mx-auto w-full max-w-3xl px-4 ${isHome ? 'pb-28' : 'pb-8'} pt-6`}>{children}</main>
    {isHome && <nav className="bottom-nav fixed bottom-0 left-0 right-0 z-10 mx-auto max-w-3xl border-t bg-card/95 px-2 py-2 backdrop-blur-md" data-testid="nav-bottom">
      {nav.map(({ href, key, icon: Icon }) => <Link href={href} key={href} className={`bottom-item ${location === href ? 'active' : ''}`} data-testid={`link-bottom-${key}`}><Icon size={18} /><span>{tr(language, key)}</span></Link>)}
    </nav>}
  </div>;
}

function SectionHeading({ eyebrow, title, detail, back }: { eyebrow?: string; title: string; detail?: string; back?: boolean }) {
  const [, setLocation] = useLocation();
  return <div className="mb-6 rise-in">
    {eyebrow && <p className="eyebrow">{eyebrow}</p>}<h1 className="page-title">{title}</h1>{detail && <p className="page-detail">{detail}</p>}
  </div>;
}

function Home({ language }: { language: Language }) {
  const cards = [
    { href: '/tickets', icon: Ticket, tone: 'pink', title: tr(language, 'tickets'), desc: language === 'ru' ? 'Подберём маршрут и отправим запрос' : language === 'uz' ? 'Yo‘nalish tanlaymiz va so‘rov yuboramiz' : 'Route planning and a ready-to-send request' },
    { href: '/visa', icon: ShieldCheck, tone: 'blue', title: tr(language, 'visa'), desc: language === 'ru' ? 'Проверка ответа и подача документов' : 'Check a response or start an application' },
    { href: '/help', icon: CircleHelp, tone: 'sand', title: tr(language, 'help'), desc: language === 'ru' ? 'Напишите вопрос специалисту' : 'A clear answer from a real specialist' },
  ];
  return <div className="space-y-7">
    <section className="hero-panel rise-in">
      <div className="relative z-[1]"><p className="eyebrow text-accent">OMAD TOUR · САНКТ-ПЕТЕРБУРГ</p><h1 className="hero-title">Ваш маршрут.<br /><span>Наше внимание.</span></h1><p className="mt-4 max-w-[280px] text-sm leading-6 text-white/75">{language === 'ru' ? 'Авиабилеты, визы и помощь — спокойно, по-человечески, рядом с консульством Узбекистана.' : 'Tickets, visas and help — calmly, humanly, near the Uzbekistan Consulate.'}</p><Link href="/tickets" className="primary-button mt-6" data-testid="link-hero-tickets">{tr(language, 'tickets')} <ArrowRight size={16} /></Link></div>
      <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" /><Plane className="hero-plane" size={92} strokeWidth={1.2} />
    </section>
    <div className="flex items-end justify-between"><div><p className="eyebrow">БЫСТРЫЙ ДОСТУП</p><h2 className="section-title">{language === 'ru' ? 'С чего начнём?' : 'Where shall we start?'}</h2></div><Link href="/requests" className="text-link" data-testid="link-see-requests">{tr(language, 'requests')} <ChevronRight size={15} /></Link></div>
    <div className="grid gap-3">{cards.map(({ href, icon: Icon, tone, title, desc }) => <Link href={href} key={href} className={`service-card tone-${tone} rise-in`} data-testid={`card-service-${href.slice(1)}`}><span className="service-icon"><Icon size={21} /></span><span className="flex-1"><strong>{title}</strong><small>{desc}</small></span><ChevronRight size={18} /></Link>)}</div>
    <section className="info-strip rise-in delay-2"><div className="info-icon"><BadgeCheck size={19} /></div><div><strong>{language === 'ru' ? 'Рядом, когда важно' : 'A dependable desk in your pocket'}</strong><p>{language === 'ru' ? 'Пока заявки сохраняются локально. Серверная связь подключится следующим шагом.' : 'Requests are local for now. Server delivery comes next after the bot token is rotated.'}</p></div></section>
    <div className="grid grid-cols-2 gap-3">
      <Link href="/specialist" className="mini-card" data-testid="card-specialist"><Headphones size={19} /><span>{tr(language, 'specialist')}</span></Link>
      <Link href="/address" className="mini-card" data-testid="card-address"><MapPin size={19} /><span>{tr(language, 'address')}</span></Link>
      <Link href="/groups" className="mini-card" data-testid="card-groups"><UsersRound size={19} /><span>{tr(language, 'groups')}</span></Link>
      <Link href="/help" className="mini-card" data-testid="card-help"><MessageCircle size={19} /><span>{tr(language, 'help')}</span></Link>
    </div>
  </div>;
}

function Counter({ label, value, onChange, testId }: { label: string; value: number; onChange: (n: number) => void; testId: string }) {
  return <div className="counter-row"><span>{label}</span><div className="counter"><button type="button" onClick={() => onChange(Math.max(0, value - 1))} data-testid={`${testId}-minus`}><Minus size={15} /></button><b data-testid={`${testId}-value`}>{value}</b><button type="button" onClick={() => onChange(value + 1)} data-testid={`${testId}-plus`}><Plus size={15} /></button></div></div>;
}

function Tickets({ language }: { language: Language }) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ origin: 'Санкт-Петербург', destination: '', date: '', child: false, infants: 0, children: 0, phone: '' });
  const [, setLocation] = useLocation();
  const [requests, setRequests] = useLocalStorage<RequestItem[]>('omad-requests', []);
  const update = (field: string, value: string | boolean) => setForm((f) => ({ ...f, [field]: value }));
  const requestText = `Запрос на авиабилет: ${form.origin} → ${form.destination}, ${form.date || 'дата уточняется'}. ${form.child ? `Младенцы: ${form.infants}, дети: ${form.children}.` : 'Только взрослые.'} Телефон: ${form.phone || 'уточнить'}.`;
  const telegramRequestLink = `${DESTINATIONS.telegram}?text=${encodeURIComponent(requestText)}`;
  const whatsappRequestLink = `${DESTINATIONS.whatsapp}?text=${encodeURIComponent(requestText)}`;
  const submit = () => {
    setRequests([{ id: `ticket-${Date.now()}`, type: 'Air ticket', title: `${form.origin} → ${form.destination}`, status: 'New', detail: requestText, created: new Date().toISOString() }, ...requests]);
    setStep(4);
  };
  return <div><SectionHeading eyebrow={`01 / 03 · ${tr(language, 'tickets')}`} title={language === 'ru' ? 'Подберём ваш билет' : 'Let’s find your route'} detail={language === 'ru' ? 'Три коротких шага — и запрос у специалиста.' : 'Three short steps, then your request is ready.'} back />
    {step < 4 && <div className="stepper"><span className="active">01</span><i /><span className={step > 1 ? 'active' : ''}>02</span><i /><span className={step > 2 ? 'active' : ''}>03</span></div>}
    <div className="form-card">
      {step === 1 && <div className="space-y-5 rise-in"><div><label className="field-label">Откуда</label><div className="input-wrap"><Plane size={17} /><input value={form.origin} onChange={(e) => update('origin', e.target.value)} placeholder="Город отправления" data-testid="input-ticket-origin" /></div></div><div><label className="field-label">Куда</label><div className="input-wrap"><MapPin size={17} /><input value={form.destination} onChange={(e) => update('destination', e.target.value)} placeholder="Город назначения" data-testid="input-ticket-destination" /></div></div><button type="button" onClick={() => form.destination && setStep(2)} className="primary-button w-full justify-center disabled:opacity-40" disabled={!form.destination} data-testid="button-ticket-step-1">{tr(language, 'next')} <ArrowRight size={16} /></button></div>}
      {step === 2 && <div className="space-y-5 rise-in"><div><label className="field-label">Дата вылета</label><div className="input-wrap"><CalendarDays size={17} /><input type="date" value={form.date} onChange={(e) => update('date', e.target.value)} data-testid="input-ticket-date" /></div></div><div className="choice-question"><div><strong>Путешествует ребёнок?</strong><small>Младенец 0–2 и ребёнок 2–12 лет</small></div><button type="button" className={`toggle ${form.child ? 'on' : ''}`} onClick={() => update('child', !form.child)} data-testid="button-toggle-child"><span /></button></div>{form.child && <div className="space-y-1 border-t pt-3"><Counter label="Младенцы 0–2 года" value={form.infants} onChange={(n) => setForm((f) => ({ ...f, infants: n }))} testId="counter-infant" /><Counter label="Дети 2–12 лет" value={form.children} onChange={(n) => setForm((f) => ({ ...f, children: n }))} testId="counter-child" /></div>}<div className="flex gap-2"><button type="button" className="secondary-button flex-1" onClick={() => setStep(1)} data-testid="button-ticket-back-2">{tr(language, 'back')}</button><button type="button" className="primary-button flex-[2] justify-center" onClick={() => setStep(3)} data-testid="button-ticket-step-2">{tr(language, 'next')} <ArrowRight size={16} /></button></div></div>}
      {step === 3 && <div className="space-y-5 rise-in"><div><label className="field-label">Куда отправить готовый запрос?</label><div className="input-wrap"><Phone size={17} /><input value={form.phone} onChange={(e) => update('phone', e.target.value)} placeholder="+7 900 000 00 00" data-testid="input-ticket-phone" /></div></div><div className="request-preview"><div className="preview-label"><FileText size={15} /> Текст запроса</div><p>{requestText}</p></div><div className="flex gap-2"><button type="button" className="secondary-button flex-1" onClick={() => setStep(2)} data-testid="button-ticket-back-3">{tr(language, 'back')}</button><button type="button" className="primary-button flex-[2] justify-center" onClick={submit} data-testid="button-ticket-submit">{tr(language, 'send')} <Send size={16} /></button></div></div>}
       {step === 4 && <div className="py-5 text-center rise-in"><div className="success-mark"><Check size={26} /></div><h2 className="section-title mt-4">Запрос tayyor</h2><p className="page-detail mx-auto">Matn tayyorlandi. Telegram yoki WhatsApp tugmasini bossangiz, yuborishga tayyor holda ochiladi.</p><div className="mt-6 grid gap-2"><a href={telegramRequestLink} target="_blank" rel="noreferrer" className="primary-button justify-center" data-testid="link-ticket-telegram"><Send size={17} /> Telegram orqali yuborish</a><a href={whatsappRequestLink} target="_blank" rel="noreferrer" className="secondary-button justify-center" data-testid="link-ticket-whatsapp"><MessageCircle size={17} /> WhatsApp orqali yuborish</a><button type="button" className="secondary-button justify-center" onClick={() => setLocation('/requests')} data-testid="button-ticket-requests">Смотреть заявки <ChevronRight size={16} /></button></div></div>}
    </div>
  </div>;
}

function Visa({ language }: { language: Language }) {
  const [location, setLocation] = useLocation();
  return <div><SectionHeading eyebrow="02 / VISA DESK" title={language === 'ru' ? 'Виза — без лишних шагов' : 'Visa, made clearer'} detail={language === 'ru' ? 'Проверяйте готовый ответ или передайте документы специалисту.' : 'Check a response or pass your documents to a specialist.'} back />
    <div className="grid gap-3"><Link href="/visa/check" className="action-panel tone-blue" data-testid="card-visa-check"><span className="service-icon"><FileCheck2 size={22} /></span><span className="flex-1"><strong>Проверить ответ визы</strong><small>Открыть официальный портал MFA Uzbekistan</small></span><ExternalLink size={17} /></Link><Link href="/visa/apply" className="action-panel tone-pink" data-testid="card-visa-apply"><span className="service-icon"><Upload size={22} /></span><span className="flex-1"><strong>Подать документы</strong><small>Barcode или номер заявки и номер телефона</small></span><ChevronRight size={17} /></Link></div>
    <div className="info-strip mt-5"><div className="info-icon"><LockKeyhole size={18} /></div><div><strong>Приватно и прозрачно</strong><p>Ваши данные остаются на устройстве до подключения серверной отправки.</p></div></div>
    {location !== '/visa' && <button type="button" onClick={() => setLocation('/visa')} className="back-link mt-5" data-testid="button-visa-back"><ArrowLeft size={16} /> Назад к визовым услугам</button>}
  </div>;
}

function VisaCheck() {
  return <div><SectionHeading eyebrow="VISA / CHECK" title="Проверка ответа" detail="Официальная страница разрешений МВД Узбекистана." back /><div className="form-card text-center"><div className="large-icon"><ExternalLink size={25} /></div><h2 className="section-title mt-4">Открыть официальный портал</h2><p className="page-detail">Omad Tour не запрашивает пароль или код подтверждения. Введите данные только на сайте MFA.</p><a href={DESTINATIONS.visa} target="_blank" rel="noreferrer" className="primary-button mt-6 justify-center" data-testid="link-visa-official">Перейти на visa.mfa.uz <ExternalLink size={16} /></a></div></div>;
}

function VisaApply() {
  const [barcode, setBarcode] = useState(''); const [manual, setManual] = useState(''); const [phone, setPhone] = useState(''); const [imageName, setImageName] = useState('');
  const [requests, setRequests] = useLocalStorage<RequestItem[]>('omad-requests', []); const [sent, setSent] = useState(false);
  const submit = () => { setRequests([{ id: `visa-${Date.now()}`, type: 'Visa application', title: 'Подача визовых документов', status: 'New', detail: `Номер: ${barcode || manual}. Телефон: ${phone}. Файл: ${imageName || 'не прикреплён'}`, created: new Date().toISOString() }, ...requests]); setSent(true); };
  return <div><SectionHeading eyebrow="VISA / APPLY" title="Передать документы" detail="Загрузите фото анкеты, укажите barcode или номер и оставьте телефон." back />{sent ? <div className="form-card text-center rise-in"><div className="success-mark"><Check size={26} /></div><h2 className="section-title mt-4">Заявка принята локально</h2><p className="page-detail">ID заявки создан. Синхронизация с оператором появится после подключения защищённого сервера.</p><Link href="/requests" className="primary-button mt-6 justify-center" data-testid="link-visa-requests">Открыть статус заявки <ChevronRight size={16} /></Link></div> : <div className="form-card space-y-5"><label className="upload-zone"><Upload size={21} /><span><strong>{imageName || 'Загрузить фото анкеты'}</strong><small>JPG, PNG — только изображение бланка</small></span><input type="file" accept="image/*" onChange={(e) => setImageName(e.target.files?.[0]?.name ?? '')} data-testid="input-visa-image" /></label><div><label className="field-label">Barcode рақами</label><div className="input-wrap"><BarChart3 size={17} /><input value={barcode} onChange={(e) => setBarcode(e.target.value)} placeholder="Сканировать или ввести barcode" data-testid="input-visa-barcode" /></div><p className="field-hint">Камера/сканерга рухсат берилса barcode автоматик ўқилади; ҳозир қўлда ҳам киритиш мумкин.</p></div><div className="or-divider"><span>или номер вручную</span></div><div><label className="field-label">Номер заявки</label><div className="input-wrap"><FileText size={17} /><input value={manual} onChange={(e) => setManual(e.target.value)} placeholder="Номер разрешения" data-testid="input-visa-manual" /></div></div><div><label className="field-label">Номер телефона</label><div className="input-wrap"><Phone size={17} /><input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+7 900 000 00 00" data-testid="input-visa-phone" /></div></div><button type="button" onClick={submit} disabled={!(barcode || manual) || !phone} className="primary-button w-full justify-center disabled:opacity-40" data-testid="button-submit-visa">{'Сохранить заявку'} <ArrowRight size={16} /></button></div>}</div>;
}

function Requests() {
  const [requests] = useLocalStorage<RequestItem[]>('omad-requests', []);
  return <div><SectionHeading eyebrow="YOUR DESK" title="Мои заявки" detail="История запросов на этом устройстве." back />{requests.length === 0 ? <div className="empty-state"><div className="large-icon"><ClipboardList size={25} /></div><h2 className="section-title mt-4">Заявок пока нет</h2><p className="page-detail">Начните с авиабилета или визовой услуги — здесь появится статус.</p><Link href="/tickets" className="primary-button mt-6 justify-center" data-testid="link-empty-tickets">Создать запрос <Plus size={16} /></Link></div> : <div className="space-y-3">{requests.map((item) => <div className="request-card rise-in" key={item.id} data-testid={`card-request-${item.id}`}><div className="flex items-start gap-3"><div className="request-icon">{item.type === 'Air ticket' ? <Ticket size={18} /> : <FileCheck2 size={18} />}</div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><strong>{item.title}</strong><span className={`status-pill status-${item.status.replace(' ', '-').toLowerCase()}`} data-testid={`status-request-${item.id}`}>{item.status}</span></div><p className="mt-1 text-xs text-muted-foreground">{item.type} · {new Date(item.created).toLocaleDateString()}</p><p className="mt-3 text-sm leading-5 text-muted-foreground">{item.detail}</p></div></div></div>)}</div>}</div>;
}

function Help() {
  const [text, setText] = useState(''); const [file, setFile] = useState(''); const [sent, setSent] = useState(false);
  return <div><SectionHeading eyebrow="DIRECT LINE" title="Чем помочь?" detail="Опишите вопрос — подготовим понятный ответ." back />{sent ? <div className="form-card text-center"><div className="success-mark"><Check size={26} /></div><h2 className="section-title mt-4">Сообщение сохранено</h2><p className="page-detail">Синхронизация с оператором подключится следующим шагом.</p><button type="button" className="secondary-button mt-6 justify-center" onClick={() => { setSent(false); setText(''); setFile(''); }} data-testid="button-help-new">Новое сообщение</button></div> : <div className="form-card space-y-5"><div><label className="field-label">Ваш вопрос</label><textarea value={text} onChange={(e) => setText(e.target.value)} rows={5} placeholder="Например: нужна виза в Узбекистан..." className="textarea" data-testid="textarea-help" /></div><label className="attachment-button"><Paperclip size={17} />{file || 'Прикрепить изображение'}<input type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0]?.name ?? '')} data-testid="input-help-image" /></label><button type="button" disabled={!text.trim()} onClick={() => setSent(true)} className="primary-button w-full justify-center disabled:opacity-40" data-testid="button-help-submit"><Send size={16} /> Отправить вопрос</button></div>}</div>;
}

function Specialist() {
  return <div><SectionHeading eyebrow="OMAD TOUR TEAM" title="Связаться со специалистом" detail="Выберите привычный канал — ответим в рабочее время." back /><div className="contact-card"><div className="avatar"><UserRound size={23} /></div><div><strong>Omad Tour</strong><p>Визы · билеты · сопровождение</p></div><span className="online-dot" /></div><div className="mt-4 grid gap-3"><a className="contact-action telegram" href={DESTINATIONS.specialistTelegram} target="_blank" rel="noreferrer" data-testid="link-contact-telegram"><Send size={19} /><span><strong>Telegram</strong><small>@AVIAKASSA9094</small></span><ExternalLink size={16} /></a><a className="contact-action" href={DESTINATIONS.specialistWhatsapp} target="_blank" rel="noreferrer" data-testid="link-contact-whatsapp"><MessageCircle size={19} /><span><strong>WhatsApp</strong><small>+7 937 949 90 94</small></span><ExternalLink size={16} /></a><a className="contact-action" href={DESTINATIONS.specialistImo} target="_blank" rel="noreferrer" data-testid="link-contact-imo"><MessageCircle size={19} /><span><strong>IMO</strong><small>+7 937 949 90 94</small></span><ExternalLink size={16} /></a><div className="grid grid-cols-2 gap-3"><a className="small-contact" href={DESTINATIONS.specialistPhone} data-testid="link-contact-call"><Phone size={17} /> Позвонить</a><a className="small-contact" href={DESTINATIONS.sms} data-testid="link-contact-sms"><MessageCircle size={17} /> SMS</a></div></div></div>;
}

function Groups() {
  const groups = [{ name: 'Oylik biletlar narxi va qulay narx', detail: 'Aviachiptalar va maxsus takliflar', href: 'https://t.me/+4RhCSj7qgnxjNWNi' }, { name: 'UZ Res Sankt-Peterburgdagi Bosh konsulxonasi', detail: 'Konsullik yangiliklari va ma’lumotlar', href: 'https://t.me/+i8I6ByH_CUVhOWQy' }];
  return <div><SectionHeading eyebrow="COMMUNITY" title="Полезные группы" detail="Каналы, которые помогают быть в курсе." back /><div className="space-y-3">{groups.map((g, i) => <a href={g.href} target="_blank" rel="noreferrer" className="group-card" key={g.name} data-testid={`link-group-${i}`}><div className="group-avatar"><Send size={17} /></div><span className="flex-1"><strong>{g.name}</strong><small>{g.detail}</small></span><ExternalLink size={16} /></a>)}</div></div>;
}

function Address() {
  return <div><SectionHeading eyebrow="FIND US" title="Мы рядом с консульством" detail="Зайдите в офис — поможем разобраться на месте." back /><div className="map-card"><div className="map-pattern"><Map size={48} /><span>Санкт-Петербург</span></div><div className="address-copy"><div className="flex items-start gap-3"><div className="request-icon"><Building2 size={18} /></div><div><strong>Omad Tour</strong><p>4-Красноармейская улица, дом 3, офис «Омад Тур»</p><p className="mt-2 text-sm text-muted-foreground">Через арку дома, домофон 22В</p><p className="mt-2 text-xs text-muted-foreground">Точный маршрут откроется в Яндекс Картах</p></div></div><a href={DESTINATIONS.maps} target="_blank" rel="noreferrer" className="primary-button mt-5 justify-center" data-testid="link-yandex-maps"><MapPin size={16} /> Открыть в Яндекс Картах <ExternalLink size={15} /></a></div></div><div className="info-strip mt-4"><div className="info-icon"><Clock3 size={18} /></div><div><strong>Перед визитом</strong><p>Напишите нам, чтобы уточнить часы работы и свободного специалиста.</p></div></div></div>;
}

function Admin() {
  const [password, setPassword] = useState(''); const [unlocked, setUnlocked] = useState(false); const [requests] = useLocalStorage<RequestItem[]>('omad-requests', []);
  const configured = Boolean(import.meta.env.VITE_OMAD_ADMIN_PASSWORD);
  if (!unlocked) return <div><SectionHeading eyebrow="PRIVATE AREA" title="Панель администратора" detail="Служебный доступ Omad Tour." back /><div className="form-card space-y-5"><div className="large-icon"><LockKeyhole size={24} /></div><div><label className="field-label">Пароль администратора</label><div className="input-wrap"><LockKeyhole size={17} /><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Введите пароль" data-testid="input-admin-password" /></div></div>{!configured && <p className="notice-text">Пароль подключается через защищённую настройку окружения. В этом первом локальном билде серверный доступ ещё не активирован.</p>}<button type="button" disabled={!configured} onClick={() => setUnlocked(password === import.meta.env.VITE_OMAD_ADMIN_PASSWORD)} className="primary-button w-full justify-center disabled:opacity-40" data-testid="button-admin-login"><LockKeyhole size={16} /> Войти</button></div></div>;
  return <div><SectionHeading eyebrow="PRIVATE AREA" title="Обзор заявок" detail="Локальный просмотр. Синхронизация с ботом будет подключена позже." back /><div className="admin-stat"><BarChart3 size={20} /><span><small>Всего локальных заявок</small><strong>{requests.length}</strong></span></div><div className="mt-4 space-y-3">{requests.length ? requests.map((r) => <div className="request-card" key={r.id}><strong>{r.title}</strong><p className="text-xs text-muted-foreground">{r.status} · {r.type}</p></div>) : <div className="empty-state"><ClipboardList size={26} /><p>Пока нет локальных заявок.</p></div>}</div></div>;
}

function NotFound() { const [, setLocation] = useLocation(); return <div className="empty-state"><X size={28} /><h1 className="section-title mt-4">Страница не найдена</h1><button type="button" className="primary-button mt-5" onClick={() => setLocation('/')} data-testid="button-not-found-home">На главную</button></div>; }

function RouterView({ language }: { language: Language }) {
  return <Switch>
    <Route path="/" component={() => <Home language={language} />} />
    <Route path="/tickets" component={() => <Tickets language={language} />} />
    <Route path="/visa" component={() => <Visa language={language} />} />
    <Route path="/visa/check" component={VisaCheck} />
    <Route path="/visa/apply" component={VisaApply} />
    <Route path="/requests" component={Requests} />
    <Route path="/help" component={Help} />
    <Route path="/specialist" component={Specialist} />
    <Route path="/groups" component={Groups} />
    <Route path="/address" component={Address} />
    <Route path="/admin" component={Admin} />
    <Route component={NotFound} />
  </Switch>;
}

function App() {
  const [language, setLanguage] = useLocalStorage<Language>('omad-language', 'ru');
  const [dark, setDark] = useLocalStorage<boolean>('omad-theme', false);
  const [taps, setTaps] = useState(0);
  useEffect(() => { document.documentElement.classList.toggle('dark', dark); }, [dark]);
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Shell language={language} setLanguage={setLanguage} dark={dark} setDark={setDark} taps={taps} setTaps={setTaps}><ErrorBoundary resetKey={location.pathname}><RouterView language={language} /></ErrorBoundary></Shell></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;